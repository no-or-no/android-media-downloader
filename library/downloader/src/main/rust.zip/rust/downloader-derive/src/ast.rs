use proc_macro2::{Ident, Span, TokenStream};
use quote::{format_ident, quote};
use syn::punctuated::Punctuated;
use syn::visit_mut::VisitMut;
use syn::{parse_quote, visit_mut, AngleBracketedGenericArguments, FnArg, GenericArgument, ItemFn, Pat, PatIdent, PatType, Path, PathArguments, PathSegment, ReturnType, Token, Type, TypePath, TypeReference, Visibility};

pub fn parse_item_fn(input: ItemFn) -> syn::Result<TokenStream> {
    let mut out = input.clone();

    let mut visitor = FnVisitor::default();
    visitor.visit_item_fn_mut(&mut out);

    let out2 = match visitor.item {
        Some(item) => quote!{ #item },
        None => quote!()
    };

    let tokens = quote! { #out #out2 };
    // println!("----------------------------------");
    // println!("{}", tokens.to_string());
    // println!("----------------------------------");
    Ok(tokens)
}

fn return_type_segments(ret: &ReturnType) -> Option<Punctuated<PathSegment, Token![::]>> {
    if let ReturnType::Type(.., tp) = ret {
        if let Type::Path(TypePath { path: Path { segments, .. }, .. }) = &**tp {
            return Some(segments.clone());
        }
    }
    None
}

#[derive(Default, Debug, Clone)]
struct FnVisitor {
    item: Option<ItemFn>,
}

impl FnVisitor {
    fn transform_native_method(&mut self, i: &mut ItemFn) {
        if let Some(segments) = return_type_segments(&i.sig.output) {
            if segments.is_empty() { return; }

            let ret_type = segments.last();
            if ret_type.is_none() { return; }
            let ret_type = ret_type.unwrap();

            if "Result" == ret_type.ident.to_string().as_str() {
                let mut old = i.clone();
                // 修改原函数的返回值类型, 去掉 Result
                if let PathArguments::AngleBracketed(AngleBracketedGenericArguments { args, ..}) = &ret_type.arguments {
                    if let GenericArgument::Type(t) = &args[0] {
                        let ret = ReturnType::Type(Token![->](Span::call_site()), Box::new(t.clone()));
                        old.sig.output = ret
                    }
                }

                // 生成新函数
                let old_fn_name = i.sig.ident.to_string();
                let fn_name = format!("__{}", old_fn_name);
                i.sig.ident = Ident::new(&fn_name, i.sig.ident.span());
                i.vis = Visibility::Inherited;
                i.attrs = vec![];

                let mut args = vec![];
                for input in &i.sig.inputs {
                    if let FnArg::Typed(PatType { pat, .. }) = input {
                        if let Pat::Ident( PatIdent { ident, .. }) = &**pat {
                            args.push(ident);
                        }
                    }
                }
                let mut env_mut = quote!();
                if let FnArg::Typed(PatType { ty, .. }) = &i.sig.inputs[0] {
                    if let Type::Reference(TypeReference { elem, .. }) = &**ty {
                        old.sig.inputs[0] = parse_quote! { mut env: #elem };
                        env_mut = quote! { &mut };
                    }
                }

                let mut ret_val = quote!();
                if let Some(segments) = return_type_segments(&old.sig.output) {
                    if !segments.is_empty() {
                        let seg = segments[0].ident.to_string();

                        ret_val = match seg.as_str() {
                            "jint" | "jlong" | "jbyte" | "jboolean" |
                            "jchar" | "jshort" | "jsize" | "jfloat" |
                            "jdouble" | "JString" | "JObject" | "JBooleanArray" |
                            "JByteArray" | "JCharArray" | "JShortArray" | "JIntArray" |
                            "JLongArray" | "JFloatArray" | "JDoubleArray" | "JObjectArray"
                            => quote! { Default::default() },
                            "jbooleanArray" | "jbyteArray" | "jcharArray" | "jshortArray" |
                            "jintArray" | "jlongArray" | "jfloatArray" | "jdoubleArray" |
                            "jobjectArray" | "jstring"
                            => quote! { std::ptr::null_mut() as jobject },
                            _ => quote! { jni::objects::JObject::null() },
                        };
                    }
                }

                let fn_name_ident = format_ident!("{}", fn_name);
                let block: syn::Block = parse_quote! {
                    {
                        #fn_name_ident(#env_mut #(#args),*).unwrap_or_else(|e| {
                            let msg = format!("native_method[{}]: {:?}", #old_fn_name, e);
                            error!("{:?}", msg);
                            //env.throw_exception(format!("native_method `{}`: {:?}", #old_fn_name, e));
                            env.throw_new("java/lang/Exception", msg).unwrap();
                            #ret_val
                        })
                    }
                };
                old.block = Box::new(block);
                self.item = Some(old);
            }
        }
    }
}

impl VisitMut for FnVisitor {
    fn visit_item_fn_mut(&mut self, i: &mut ItemFn) {
        self.transform_native_method(i);
        visit_mut::visit_item_fn_mut(self, i);
    }
}
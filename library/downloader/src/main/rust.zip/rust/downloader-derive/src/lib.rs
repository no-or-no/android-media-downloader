use proc_macro::TokenStream;

mod ast;

/// 用于将返回值为 [Result] 类型转换为 T, 如果返回值为 JObject 类型或它的变体类型,
/// 返回到 java 层时可能为 null
#[proc_macro_attribute]
pub fn native_method(_attr: TokenStream, item: TokenStream) -> TokenStream {
    let input = syn::parse_macro_input!(item as syn::ItemFn);
    let tokens = ast::parse_item_fn(input).unwrap_or_else(|e| e.to_compile_error());
    tokens.into()
}

use crate::jni_ext::{get_string, throw_exception};
use crate::{define_android_jni, m3u8};
use anyhow::{bail, Result};
use downloader_derive::native_method;
use jni::objects::{JByteArray, JClass, JString};
use jni::sys::{jboolean, jint, JNI_ERR, JNI_TRUE};
use jni::{JNIEnv, JavaVM};
use log::{error, info, LevelFilter};
use std::ffi::c_void;
use std::time::Instant;
use serde_json::json;
use crate::m3u8::{ M3U8};

define_android_jni! {
    "a/b/c/CApi" => [
        "a1", "(ZLjava/lang/String;)V", init_android_log
        "a2", "(Ljava/lang/String;)[B", parse_m3u8
    ],
}

#[unsafe(no_mangle)]
#[allow(non_snake_case)]
pub unsafe extern "system" fn JNI_OnLoad(jvm: JavaVM, _reserved: *mut c_void) -> jint {
    let mut env = jvm.get_env().unwrap();
    let java_version = env.get_version().unwrap().into();

    match register_native_methods(&mut env) {
        Ok(_) => java_version,
        Err(e) => {
            throw_exception(&mut env, format!("{:?}", e));
            JNI_ERR
        }
    }
}

fn init_android_log(env: &mut JNIEnv, _class: JClass, enable: jboolean, tag: JString) {
    if enable == JNI_TRUE {
        let tag = match unsafe { env.get_string_unchecked(&tag) } {
            Ok(tag) => String::from(tag),
            Err(_) => String::from("WMT-Native"),
        };

        android_logger::init_once(
            android_logger::Config::default()
                .with_max_level(LevelFilter::Trace)
                .with_tag(tag)
        );

        info!("android logging enabled!");
    }
}

#[native_method]
fn parse_m3u8<'a>(env: &mut JNIEnv<'a>, _class: JClass<'a>, path: JString<'a>) -> Result<JByteArray<'a>> {
    let path = get_string(env, &path)?;
    info!("parse_m3u8: {}", path);
    let m3u8 = m3u8::parse_m3u8(&path)?;
    info!("result: {:?}", m3u8);

    let vec = serde_json::to_vec(&m3u8)?;
    // cbor 序列化
    // let mut vec = vec![];
    // ciborium::into_writer(&m3u8, &mut vec)?;

    let arr = env.byte_array_from_slice(&vec)?;
    Ok(arr)
}
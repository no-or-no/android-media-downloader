#![allow(unused)]
use anyhow::*;
use jni::descriptors::Desc;
use jni::JNIEnv;
use jni::objects::{JClass, JObject, JObjectArray, JString};
use jni::sys::{jlong, jsize};
use log::*;

pub const EXCEPTION_CLASS: &str = "java/lang/Exception";
pub const STRING_CLASS: &str = "java/lang/String";

#[macro_export(local_inner_macros)]
macro_rules! jni_method {
    ($method_name:expr, $signature:expr, $native_method:tt) => {
        jni::NativeMethod {
            name: jni::strings::JNIString::from($method_name),
            sig: jni::strings::JNIString::from($signature),
            fn_ptr: $native_method as *mut core::ffi::c_void,
        }
    };
}

#[macro_export(local_inner_macros)]
macro_rules! define_android_jni {
    ($($class_name:expr => [$($method_name:expr, $signature:expr, $native_method:tt)+],)+) => {
        pub(crate) fn register_native_methods(env: &mut jni::JNIEnv) -> jni::errors::Result<()> {
            $(
            let clazz = env.find_class($class_name)?;
            env.register_native_methods(clazz, &[
                $(
                crate::jni_method!($method_name, $signature, $native_method),
                )+
            ])?;
            )+
            Ok(())
        }
    };
    () => {
        pub(crate) fn register_native_methods(env: &jni::JNIEnv) -> anyhow::Result<()> {
            Ok(())
        }
    };
}



/// 转换为指针回传给 java
pub fn into_jni_ptr<T>(x: T) -> jlong {
    Box::into_raw(Box::new(x)) as jlong
}

/// 从 java 传来的指针
pub fn from_jni_ptr<'a, T>(ptr: jlong) -> anyhow::Result<&'a mut T> {
    if ptr == 0 { bail!("jni ptr 0") }
    Ok(unsafe { &mut *(ptr as *mut T) })
}

/// 释放指针
pub fn release_jni_ptr<T>(ptr: jlong) {
    unsafe {
        drop(Box::from_raw(ptr as *mut T));
    }
}

pub fn get_string(env: &JNIEnv, s: &JString) -> Result<String> {
    let s = unsafe { env.get_string_unchecked(s)? };
    Ok(String::from(s))
}

pub fn get_string_array(env: &mut JNIEnv, arr: &JObjectArray) -> Result<Vec<String>> {
    let size = env.get_array_length(arr)?;
    let mut vec = vec![];
    for i in 0..size {
        let o = env.get_object_array_element(arr, i)?;
        let s = JString::from(o);
        let s = unsafe { env.get_string_unchecked(&s) }?;
        vec.push(String::from(s));
    }
    Ok(vec)
}

pub fn new_string_array<'a>(env: &mut JNIEnv<'a>, vec: Vec<String>) -> Result<JObjectArray<'a>> {
    let len = vec.len();
    let arr = env.new_object_array(len as jsize, STRING_CLASS, JObject::null())?;
    if len > 0 {
        for i in 0 .. len {
            let s = env.new_string(&vec[i])?;
            env.set_object_array_element(&arr, i as jsize, s)?;
        }
    }
    Ok(arr)
}

#[inline]
pub fn new_empty_string_array<'a>(env: &mut JNIEnv<'a>) -> JObjectArray<'a> {
    new_empty_object_array(env, STRING_CLASS)
}

pub fn new_object_array<'a, 'c, C>(env: &mut JNIEnv<'a>, vec: Vec<JObject>, element_class: C) -> Result<JObjectArray<'a>>
where
    C: Desc<'a, JClass<'c>>,
{
    let len = vec.len();
    let arr = env.new_object_array(len as jsize, element_class, JObject::null())?;
    if len > 0 {
        for i in 0..len {
            env.set_object_array_element(&arr, i as jsize, &vec[i])?;
        }
    }
    Ok(arr)
}

pub fn new_empty_object_array<'a, 'c, C>(env: &mut JNIEnv<'a>, element_class: C) -> JObjectArray<'a>
where
    C: Desc<'a, JClass<'c>>,
{
    env.new_object_array(0, element_class, JObject::null()).unwrap()
}

/// 抛异常
#[inline]
pub fn throw_exception(env: &mut JNIEnv, msg: String) {
    error!("throw_exception: {:?}", msg);
    env.throw_new(EXCEPTION_CLASS, msg).unwrap();
}

use anyhow::{bail, Result};
use m3u8_rs::{AlternativeMedia, ByteRange, ClosedCaptionGroupId, DateRange, ExtTag, Key, Map, MasterPlaylist, MediaPlaylist, MediaSegment, Playlist, Resolution, SessionData, SessionDataField, SessionKey, Start, VariantStream};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::File;
use std::io::Read;
use std::path::Path;

/// 解析 m3u8 文件
pub fn parse_m3u8<T: AsRef<Path>>(path: T) -> Result<M3U8> {
    let path = path.as_ref();
    if !path.exists() { bail!("m3u8 file does not exist: {:?}", path); }

    let mut file = File::open(path)?;
    let mut bytes = Vec::new();
    file.read_to_end(&mut bytes)?;

    let parsed = m3u8_rs::parse_playlist(&bytes);
    let playlist = match parsed {
        Ok((_, playlist)) => playlist,
        Err(e) => bail!("{}", e),
    };

    Ok(playlist.into())
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum M3U8 {
    // #[serde(rename = "@@MasterPlaylist@@")]
    MasterPlaylist {
        version: Option<usize>,
        variants: Vec<M3U8StreamInfo>,
        session_data: Vec<M3U8SessionData>,
        session_key: Vec<M3U8Key>,
        start: Option<M3U8Start>,
        independent_segments: bool,
        alternatives: Vec<M3U8Media>, // EXT-X-MEDIA tags
        unknown_tags: Vec<M3U8ExtTag>,
    },
    // #[serde(rename = "@@MediaPlaylist@@")]
    MediaPlaylist {
        version: Option<usize>,
        target_duration: u64,
        media_sequence: u64,
        segments: Vec<M3U8MediaSegment>,
        discontinuity_sequence: u64,
        end_list: bool,
        playlist_type: Option<String>,
        i_frames_only: bool,
        start: Option<M3U8Start>,
        independent_segments: bool,
        unknown_tags: Vec<M3U8ExtTag>,
    },
}

impl From<Playlist> for M3U8 {
    fn from(value: Playlist) -> Self {
        match value {
            Playlist::MasterPlaylist(p) => p.into(),
            Playlist::MediaPlaylist(p) => p.into(),
        }
    }
}


impl From<MasterPlaylist> for M3U8 {
    fn from(value: MasterPlaylist) -> Self {
        Self::MasterPlaylist {
            version: value.version,
            variants: value.variants.into_iter().map(M3U8StreamInfo::from).collect(),
            session_data: value.session_data.into_iter().map(M3U8SessionData::from).collect(),
            session_key: value.session_key.into_iter().map(M3U8Key::from).collect(),
            start: value.start.map(M3U8Start::from),
            independent_segments: value.independent_segments,
            alternatives: value.alternatives.into_iter().map(M3U8Media::from).collect(),
            unknown_tags: value.unknown_tags.into_iter().map(M3U8ExtTag::from).collect(),
        }
    }
}


impl From<MediaPlaylist> for M3U8 {
    fn from(value: MediaPlaylist) -> Self {
        Self::MediaPlaylist {
            version: value.version,
            target_duration: value.target_duration,
            media_sequence: value.media_sequence,
            segments: value.segments.into_iter().map(M3U8MediaSegment::from).collect(),
            discontinuity_sequence: value.discontinuity_sequence,
            end_list: value.end_list,
            playlist_type: value.playlist_type.map(|it| format!("{}", it)),
            i_frames_only: value.i_frames_only,
            start: value.start.map(M3U8Start::from),
            independent_segments: value.independent_segments,
            unknown_tags: value.unknown_tags.into_iter().map(M3U8ExtTag::from).collect(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8StreamInfo {
    is_i_frame: bool,
    uri: String,
    bandwidth: u64,
    average_bandwidth: Option<u64>,
    codecs: Option<String>,
    resolution: Option<M3U8Resolution>,
    frame_rate: Option<f64>,
    hdcp_level: Option<String>,
    audio: Option<String>,
    video: Option<String>,
    subtitles: Option<String>,
    closed_captions: Option<String>,
    other_attributes: Option<HashMap<String, String>>,
}

impl From<VariantStream> for M3U8StreamInfo {
    fn from(value: VariantStream) -> Self {
        Self {
            is_i_frame: value.is_i_frame,
            uri: value.uri,
            bandwidth: value.bandwidth,
            average_bandwidth: value.average_bandwidth,
            codecs: value.codecs,
            resolution: value.resolution.map(M3U8Resolution::from),
            frame_rate: value.frame_rate,
            hdcp_level: value.hdcp_level.map(|it| format!("{}", it)),
            audio: value.audio,
            video: value.video,
            subtitles: value.subtitles,
            closed_captions: value.closed_captions.and_then(|it| match it {
                ClosedCaptionGroupId::None => None,
                ClosedCaptionGroupId::GroupId(s) => Some(s),
                ClosedCaptionGroupId::Other(s) => Some(s),
            }),
            other_attributes: value.other_attributes.map(|it| {
                it.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect()
            }),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8SessionData {
    data_id: String,
    field: String,
    language: Option<String>,
    other_attributes: Option<HashMap<String, String>>,
}

impl From<SessionData> for M3U8SessionData {
    fn from(value: SessionData) -> Self {
        Self {
            data_id: value.data_id,
            field: match value.field {
                SessionDataField::Value(s) => s,
                SessionDataField::Uri(s) => s,
            },
            language: value.language,
            other_attributes: value.other_attributes.map(|it| {
                it.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect()
            }),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8Key {
    method: String,
    uri: Option<String>,
    iv: Option<String>,
    keyformat: Option<String>,
    keyformatversions: Option<String>,
}

impl From<SessionKey> for M3U8Key {
    fn from(value: SessionKey) -> Self {
        value.0.into()
    }
}

impl From<Key> for M3U8Key {
    fn from(value: Key) -> Self {
        Self {
            method: format!("{}", value.method),
            uri: value.uri,
            iv: value.iv,
            keyformat: value.keyformat,
            keyformatversions: value.keyformatversions,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8Start {
    time_offset: f64,
    precise: Option<bool>,
    other_attributes: HashMap<String, String>,
}

impl From<Start> for M3U8Start {
    fn from(value: Start) -> Self {
        Self {
            time_offset: value.time_offset,
            precise: value.precise,
            other_attributes: value.other_attributes.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8Media {
    media_type: String,
    uri: Option<String>,
    group_id: String,
    language: Option<String>,
    assoc_language: Option<String>,
    name: String, // All EXT-X-MEDIA tags in the same Group MUST have different NAME attributes.
    default: bool, // Its absence indicates an implicit value of NO
    autoselect: bool, // Its absence indicates an implicit value of NO
    forced: bool, // Its absence indicates an implicit value of NO
    instream_id: Option<String>,
    characteristics: Option<String>,
    channels: Option<String>,
    other_attributes: Option<HashMap<String, String>>,
}

impl From<AlternativeMedia> for M3U8Media {
    fn from(value: AlternativeMedia) -> Self {
        Self {
            media_type: format!("{}", value.media_type),
            uri: value.uri,
            group_id: value.group_id,
            language: value.language,
            assoc_language: value.assoc_language,
            name: value.name,
            default: value.default,
            autoselect: value.autoselect,
            forced: value.forced,
            instream_id: value.instream_id.map(|it| format!("{}", it)),
            characteristics: value.characteristics,
            channels: value.channels,
            other_attributes: value.other_attributes.map(|it| {
                it.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect()
            }),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8ExtTag {
    tag: String,
    rest: Option<String>,
}

impl From<ExtTag> for M3U8ExtTag {
    fn from(value: ExtTag) -> Self {
        Self {
            tag: value.tag,
            rest: value.rest,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8MediaSegment {
    uri: String,
    duration: f32,
    title: Option<String>,
    byte_range: Option<M3U8ByteRange>,
    discontinuity: bool,
    key: Option<M3U8Key>,
    map: Option<M3U8Map>,
    program_date_time: Option<i64>,
    daterange: Option<M3U8DateRange>,
    unknown_tags: Vec<M3U8ExtTag>,
}

impl From<MediaSegment> for M3U8MediaSegment {
    fn from(value: MediaSegment) -> Self {
        Self {
            uri: value.uri,
            duration: value.duration,
            title: value.title,
            byte_range: value.byte_range.map(M3U8ByteRange::from),
            discontinuity: value.discontinuity,
            key: value.key.map(M3U8Key::from),
            map: value.map.map(M3U8Map::from),
            program_date_time: value.program_date_time.map(|it| it.timestamp_millis()),
            daterange: value.daterange.map(M3U8DateRange::from),
            unknown_tags: value.unknown_tags.into_iter().map(M3U8ExtTag::from).collect(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8ByteRange {
    length: u64,
    offset: Option<u64>,
}

impl From<ByteRange> for M3U8ByteRange {
    fn from(value: ByteRange) -> Self {
        Self {
            length: value.length,
            offset: value.offset,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8Map {
    uri: String,
    byte_range: Option<M3U8ByteRange>,
    other_attributes: HashMap<String, String>,
}

impl From<Map> for M3U8Map {
    fn from(value: Map) -> Self {
        Self {
            uri: value.uri,
            byte_range: value.byte_range.map(M3U8ByteRange::from),
            other_attributes: value.other_attributes.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect(),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8DateRange {
    id: String,
    class: Option<String>,
    start_date: i64,
    end_date: Option<i64>,
    duration: Option<f64>,
    planned_duration: Option<f64>,
    x_prefixed: Option<HashMap<String, String>>, //  X-<client-attribute>
    end_on_next: bool,
    other_attributes: Option<HashMap<String, String>>,
}

impl From<DateRange> for M3U8DateRange {
    fn from(value: DateRange) -> Self {
        Self {
            id: value.id,
            class: value.class,
            start_date: value.start_date.timestamp_millis(),
            end_date: value.end_date.map(|it| it.timestamp_millis()),
            duration: value.duration,
            planned_duration: value.planned_duration,
            x_prefixed: value.x_prefixed.map(|it| {
                it.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect()
            }),
            end_on_next: value.end_on_next,
            other_attributes: value.other_attributes.map(|it| {
                it.into_iter().map(|(k, v)| (k, v.as_str().to_string())).collect()
            }),
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct M3U8Resolution {
    width: u64,
    height: u64,
}

impl From<Resolution> for M3U8Resolution {
    fn from(value: Resolution) -> Self {
        Self {
            width: value.width,
            height: value.height,
        }
    }
}
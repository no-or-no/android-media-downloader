use std::env::current_dir;
use downloader::m3u8;

fn main() {
    let path = current_dir().unwrap()
        .join("sample")
        .join("assets")
        .join("x9i1382.m3u8");
    let res = m3u8::parse_m3u8(path);
    println!("{:#?}", res);
}

@file:Suppress("NOTHING_TO_INLINE", "FunctionName")
package wmt.downloader.task

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import wmt.downloader.define.DownloadTaskState
import wmt.downloader.define.VideoType
import androidx.media3.downloader.util.ifNullOrEmpty
import androidx.media3.downloader.util.md5

inline fun DownloadTaskInfo(
    url: String,
    originUrl: String,
    resolution: String?,
    title: String,
    coverUrl: String?,
) = DownloadTaskInfo(
    id = 0,
    url = url,
    originUrl = originUrl,
    resolution = resolution,
    title = title,
    coverUrl = coverUrl,
    createTime = System.currentTimeMillis(),
    filename = null,
    videoType = VideoType.Unknown,
    coverLocalPath = null,
    state = DownloadTaskState.NotSet,
    progress = 0f,
    totalBytes = 0,
    receivedBytes = 0,
    mimeType = "",
)

class DownloadTaskInfo @PublishedApi internal constructor(
    internal var id: Long,
    val url: String,
    val originUrl: String,
    val resolution: String?,
    val title: String,
    val coverUrl: String?,
    val createTime: Long,
    filename: String?,
    videoType: VideoType,
    mimeType: String,
    coverLocalPath: String?,
    state: DownloadTaskState,
    progress: Float, // [0, 1]
    totalBytes: Long,
    receivedBytes: Long,
) {
    var mimeType: String = mimeType; internal set
    var videoType: VideoType = videoType; internal set
    var filename: String = filename.ifNullOrEmpty { url.md5() }; internal set

    @PublishedApi
    internal val _coverLocalPath = MutableStateFlow(coverLocalPath)
    val coverLocalPathFlow = _coverLocalPath.asStateFlow()
    inline var coverLocalPath: String?
        get() = _coverLocalPath.value
        internal set(value) { _coverLocalPath.value = value }

    @PublishedApi
    internal val _state = MutableStateFlow(state)
    val stateFlow = _state.asStateFlow()
    inline var state: DownloadTaskState
        get() = _state.value
        internal set(value) { _state.value = value }

    @PublishedApi
    internal val _progress = MutableStateFlow(progress)
    val progressFlow = _progress.asStateFlow()
    inline var progress: Float
        get() = _progress.value
        internal set(value) { _progress.value = value }

    @PublishedApi
    internal val _totalBytes = MutableStateFlow(totalBytes)
    val totalBytesFlow = _totalBytes.asStateFlow()
    inline var totalBytes: Long
        get() = _totalBytes.value
        internal set(value) { _totalBytes.value = value }

    @PublishedApi
    internal val _receivedBytes = MutableStateFlow(receivedBytes)
    val receivedBytesFlow = _receivedBytes.asStateFlow()
    inline var receivedBytes: Long
        get() = _receivedBytes.value
        internal set(value) { _receivedBytes.value = value }

    internal val monitorBytes = MutableStateFlow(0L)
    internal val monitorBytesPerSecond = MutableStateFlow("")
    /** 下载速度 */
    val speedFlow = monitorBytesPerSecond.asStateFlow()
}

/** true 表示任务可执行, 不可执行的任务包括: 出错, 已暂停, NotSet */
internal fun DownloadTaskInfo.executable(): Boolean {
    return state > DownloadTaskState.NotSet && state < DownloadTaskState.Downloading
}

package wmt.downloader.database

import androidx.room.TypeConverter
import wmt.downloader.define.DownloadTaskState
import wmt.downloader.define.VideoType
import java.util.Date
import kotlin.time.Duration

// room 2.6.0 开始支持 ksp 编译 value class
@Suppress("FunctionName", "Unused")
internal class Converters {
    @TypeConverter
    fun millis_date(value: Long?) = value?.let { Date(it) }

    @TypeConverter
    fun date_millis(date: Date?) = date?.time

    @TypeConverter
    fun duration_string(d: Duration?): String? = d?.toIsoString()

    @TypeConverter
    fun string_duration(s: String?): Duration? = s?.let { Duration.parseIsoStringOrNull(it) }

    @TypeConverter
    fun videoType_string(type: String) = VideoType.from(type)

    @TypeConverter
    fun string_videoType(type: VideoType) = type.value

    @TypeConverter
    fun downloadTaskState_int(state: Int) = DownloadTaskState(state)

    @TypeConverter
    fun downloadTaskState_int(state: DownloadTaskState) = state.value
}
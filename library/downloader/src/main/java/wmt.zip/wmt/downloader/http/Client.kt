package wmt.downloader.http

import android.annotation.SuppressLint
import android.util.Log
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.logging.EMPTY
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import okhttp3.Cache
import okhttp3.OkHttpClient
import java.io.File
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSession
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager

/**
 * @param cacheFile 如: context.cacheDir.resolve("http_cache")
 */
fun newHttpClient(
    cacheFile: File? = null,
    cacheSize: Long = 64 * 1024 * 1024, // 64M
    requestTimeout: Long = 15_000,
    connectTimeout: Long = 15_000,
    socketTimeout: Long = 15_000,
    trustAll: Boolean = true,
    enableLog: Boolean = true,
    logTag: String = "http",
): HttpClient {
    return HttpClient(OkHttp) {
        followRedirects = true

        // 配置 OkHttpClient
        engine {
            config {
                cacheFile?.let { cache(Cache(it, cacheSize)) }
                trustAll(trustAll)
            }
        }
        // 重试
//        install(HttpRequestRetry) {
//            retryOnException(maxRetries = 3, retryOnTimeout = true)
//            retryOnServerErrors(0)
//            exponentialDelay()
//        }
        // 超时
        install(HttpTimeout) {
            requestTimeoutMillis = requestTimeout
            connectTimeoutMillis = connectTimeout
            socketTimeoutMillis = socketTimeout
        }
        // 日志打印
        install(Logging) {
            level = LogLevel.ALL
            logger = Logger(enableLog, logTag)
        }
    }
}

private fun Logger(enable: Boolean, tag: String): Logger {
    return if (enable) object : Logger {
        override fun log(message: String) {
            Log.d(tag, message)
        }
    } else Logger.EMPTY
}

private fun OkHttpClient.Builder.trustAll(trust: Boolean) = apply {
    if (trust) {
        val factory = createSSLSocketFactory() ?: return@apply
        sslSocketFactory(factory, TrustAllManager)
        hostnameVerifier(TrustAllHostnameVerifier)
    }
}

private fun createSSLSocketFactory(): SSLSocketFactory? {
    return runCatching {
        val sc = SSLContext.getInstance("TLS")
        sc.init(null, arrayOf(TrustAllManager), SecureRandom())
        sc.socketFactory
    }.getOrNull()
}

@SuppressLint("TrustAllX509TrustManager", "CustomX509TrustManager")
private object TrustAllManager : X509TrustManager {
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
}

private object TrustAllHostnameVerifier : HostnameVerifier {
    @SuppressLint("BadHostnameVerifier")
    override fun verify(hostname: String?, session: SSLSession?): Boolean = true
}
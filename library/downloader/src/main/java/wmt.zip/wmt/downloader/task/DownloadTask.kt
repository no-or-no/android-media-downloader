package wmt.downloader.task

import kotlinx.coroutines.Job
import wmt.downloader.define.DownloadTaskState

interface DownloadTask {
    val info: DownloadTaskInfo

    /**
     * 开始下载, 并将任务状态置为 [DownloadTaskState.Downloading]
     */
    suspend fun start()

    fun stop()
}
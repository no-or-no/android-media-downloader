package wmt.downloader.define

@JvmInline
value class DownloadTaskState internal constructor(val value: Int) {
    companion object {
        val NotSet = DownloadTaskState(0)
        val Pending = DownloadTaskState(1)
        val Prepared = DownloadTaskState(2)
        val Downloading = DownloadTaskState(3)
//        val PlayReady = DownloadTaskState(4) // 可以边下边播
        val Paused = DownloadTaskState(4)
        val Completed = DownloadTaskState(9)
        val Transforming = DownloadTaskState(10)
        val Error = DownloadTaskState(-100)
    }

    operator fun compareTo(other: DownloadTaskState): Int {
        return value.compareTo(other.value)
    }
}
package wmt.downloader.task.m3u8

import androidx.media3.downloader.util.Log
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.prepareGet
import io.ktor.http.contentLength
import io.ktor.http.isSuccess
import io.ktor.http.userAgent
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.core.remaining
import io.ktor.utils.io.exhausted
import io.ktor.utils.io.readRemaining
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.io.asSink
import kotlinx.io.buffered
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.cbor.Cbor
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.decodeFromStream
import wmt.downloader.MediaDownloader
import wmt.downloader.define.DownloadTaskState
import wmt.downloader.http.newHttpClient
import wmt.downloader.task.DownloadTask
import wmt.downloader.task.DownloadTaskInfo
import wmt.downloader.task.speedMonitor
import androidx.media3.downloader.util.md5

internal class M3U8DownloadTask(override val info: DownloadTaskInfo) : DownloadTask {
    companion object {
        private const val TAG = "M3U8DownloadTask"
        private val Json = Json {
            coerceInputValues = true
            ignoreUnknownKeys = true
            isLenient = true
            encodeDefaults = true
            prettyPrint = false
        }
        @OptIn(ExperimentalSerializationApi::class)
        private val Cbor = Cbor {
            encodeDefaults = true
            ignoreUnknownKeys = true
        }
    }
    private var job: Job? = null
    private var monitorJob: Job? = null

    private val md5 = info.url.md5()
    private val outDir = MediaDownloader.cacheDir.resolve(md5)

    override suspend fun start() {
        if (job?.isActive == true) return

        job = MediaDownloader.launch(Dispatchers.IO) {
            if (!outDir.exists()) {
                outDir.mkdirs()
            }

            val client = newHttpClient(
                enableLog = Log.enable,
                logTag = "${Log.TAG}/${MediaDownloader.TAG}/",
            )
            parseM3U8(client)
            // TODO
        }
        monitorJob = info.speedMonitor()
    }

    override fun stop() {
        job?.cancel()
        job = null
        monitorJob?.cancel()
        monitorJob = null
    }

    @OptIn(ExperimentalSerializationApi::class)
    private suspend fun parseM3U8(client: HttpClient) {
        val m3u8File = outDir.resolve("${info.filename}.m3u8")
        // 下载 m3u8
        if (!m3u8File.exists() || m3u8File.length() == 0L) {
            Log.i(msg = "download m3u8: ${info.url}")

            try {
                client.prepareGet(info.url) {
                    userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36")
                }.execute { response ->
//                    Log.i(msg = "[${response.duration}] response: ${response.status}")
                    if (response.status.isSuccess()) {
                        val channel: ByteReadChannel = response.body()
                        val stream = m3u8File.outputStream().asSink().buffered()
                        var receivedBytes = 0L
                        stream.use {
                            while (!channel.exhausted()) {
                                val chunk = channel.readRemaining()
                                val remaining = chunk.remaining
                                receivedBytes += remaining
                                info.monitorBytes.update { it + remaining }

                                chunk.transferTo(stream)
                                val contentLength = response.contentLength()
                                if (contentLength != null) {
                                    Log.i(msg = "received $receivedBytes bytes from $contentLength")
                                } else {
                                    Log.i(msg = "received $receivedBytes bytes")
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(e = e)
                info.state = DownloadTaskState.Error
            }
        }
        if (!m3u8File.exists() || m3u8File.length() == 0L) {
            Log.e(msg = "m3u8 file not found or empty: $m3u8File")
            info.state = DownloadTaskState.Error
            return
        }

        // 解析 m3u8
        Log.i(msg = "parse m3u8: $m3u8File")
        val playlist = try {
            val json = CApi.a2(m3u8File.absolutePath)
            if (json.isEmpty()) {
                info.state = DownloadTaskState.Error
                Log.e(msg = "parse m3u8 empty")
                return
            }
            Json.decodeFromStream<M3U8Playlist>(json.inputStream())
//            Json.decodeFromString<M3U8Playlist>(String(json))
        } catch (e: Exception) {
            Log.e(e = e)
            info.state = DownloadTaskState.Error
            return
        }
        Log.e(msg = "m3u8 playlist: $playlist")

        when (playlist) {
            is MasterPlaylist -> {
                var variant: M3U8StreamInfo? = null
                if (!info.resolution.isNullOrEmpty()) {
                    variant = playlist.variants.find {
                        it.resolution?.run { "${width}x$height" == info.resolution } ?: false
                    }
                }
                if (variant == null) {
                    variant = playlist.variants.firstOrNull()
                }
                if (variant == null) {
                    info.state = DownloadTaskState.Error
                    Log.e(msg = "MasterPlaylist no variant")
                    return
                }


            }
            is MediaPlaylist -> {

            }
        }
        // TODO



    }

    private fun downloadM3U8(client: HttpClient, url: String, filename: String) = channelFlow<Long> {
        val m3u8File = if (filename.endsWith(".m3u8")) {
            outDir.resolve(filename)
        } else {
            outDir.resolve("${filename}.m3u8")
        }
        try {
            client.prepareGet(url) {
                userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36")
            }.execute { response ->
//                Log.i(msg = "[${response.duration}] response: ${response.status}, $url")
                if (response.status.isSuccess()) {
                    val channel: ByteReadChannel = response.body()
                    val stream = m3u8File.outputStream().asSink().buffered()
                    var receivedBytes = 0L
                    stream.use {
                        while (!channel.exhausted()) {
                            val chunk = channel.readRemaining()
                            val remaining = chunk.remaining
                            receivedBytes += remaining
                            trySend(remaining)

                            chunk.transferTo(stream)
                            val contentLength = response.contentLength()
                            if (contentLength != null) {
                                Log.i(msg = "received $receivedBytes bytes from $contentLength")
                            } else {
                                Log.i(msg = "received $receivedBytes bytes")
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(e = e)
            close(e)
        }
    }
}
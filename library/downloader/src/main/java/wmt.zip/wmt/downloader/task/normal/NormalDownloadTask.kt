package wmt.downloader.task.normal

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import wmt.downloader.MediaDownloader
import wmt.downloader.define.DownloadTaskState
import wmt.downloader.task.DownloadTask
import wmt.downloader.task.DownloadTaskInfo

/** 常规文件下载 */
internal class NormalDownloadTask(override val info: DownloadTaskInfo) : DownloadTask {
    private var job: Job? = null

    override suspend fun start() {
        if (job?.isActive == true) return

        job = MediaDownloader.launch(Dispatchers.IO) {
            // TODO
        }
    }

    override fun stop() {
        job?.cancel()
        job = null
    }
}
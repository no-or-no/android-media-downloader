package wmt.downloader

import java.io.File

/**
 * @param downloadDir 下载目录
 * @param cacheDir 缓存目录
 * @param parallelism 同时下载任务数
 */
class MediaDownloadConfig(
    val downloadDir: File? = null,
    val cacheDir: File? = null,
    val parallelism: Int = 1,
    val enableLog: Boolean = true,
)
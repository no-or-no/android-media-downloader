package wmt.downloader.task.m3u8

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
sealed interface M3U8Playlist

@Serializable
@SerialName("MasterPlaylist")
data class MasterPlaylist(
    @SerialName("version")
    val version: Int? = null,
    @SerialName("variants")
    val variants: List<M3U8StreamInfo> = emptyList(),
    @SerialName("session_data")
    val sessionData: List<M3U8SessionData> = emptyList(),
    @SerialName("session_key")
    val sessionKey: List<M3U8Key> = emptyList(),
    @SerialName("start")
    val start: M3U8Start? = null,
    @SerialName("independent_segments")
    val isIndependentSegments: Boolean = false,
    @SerialName("alternatives")
    val alternatives: List<M3U8Media> = emptyList(),
    @SerialName("unknown_tags")
    val unknownTags: List<M3U8ExtTag> = emptyList(),
) : M3U8Playlist

@Serializable
@SerialName("MediaPlaylist")
data class MediaPlaylist(
    @SerialName("version")
    val version: Int? = null,
    @SerialName("target_duration")
    val targetDuration: Long = 0,
    @SerialName("media_sequence")
    val mediaSequence: Long = 0,
    @SerialName("segments")
    val segments: List<M3U8MediaSegment> = emptyList(),
    @SerialName("discontinuity_sequence")
    val discontinuitySequence: Long = 0,
    @SerialName("end_list")
    val isEndList: Boolean = false,
    @SerialName("playlist_type")
    val playlistType: String? = null,
    @SerialName("i_frames_only")
    val isIFramesOnly: Boolean = false,
    @SerialName("start")
    val start: M3U8Start? = null,
    @SerialName("independent_segments")
    val isIndependentSegments: Boolean = false,
    @SerialName("unknown_tags")
    val unknownTags: List<M3U8ExtTag> = emptyList(),
) : M3U8Playlist

@Serializable
data class M3U8StreamInfo(
    @SerialName("is_i_frame")
    val isIFrame: Boolean = false,
    @SerialName("uri")
    val uri: String = "",
    @SerialName("bandwidth")
    val bandwidth: Long = 0,
    @SerialName("average_bandwidth")
    val averageBandwidth: Long? = null,
    @SerialName("codecs")
    val codecs: String? = null,
    @SerialName("resolution")
    val resolution: M3U8Resolution? = null,
    @SerialName("frame_rate")
    val frameRate: Double? = null,
    @SerialName("hdcp_level")
    val hdcpLevel: String? = null,
    @SerialName("audio")
    val audio: String? = null,
    @SerialName("video")
    val video: String? = null,
    @SerialName("subtitles")
    val subtitles: String? = null,
    @SerialName("closed_captions")
    val closedCaptions: String? = null,
    @SerialName("other_attributes")
    val otherAttrs: Map<String, String>? = null,
)

/**
 * [`#EXT-X-SESSION-DATA:<attribute-list>`](https://tools.ietf.org/html/draft-pantos-http-live-streaming-19#section-4.3.4.4)
 * The EXT-X-SESSION-DATA tag allows arbitrary session data to be carried
 * in a Master Playlist.
 */
@Serializable
data class M3U8SessionData(
    @SerialName("data_id")
    val dataId: String = "",
    @SerialName("field")
    val field: String = "",
    @SerialName("language")
    val language: String? = null,
    @SerialName("other_attributes")
    val otherAttrs: Map<String, String>? = null,
)

@Serializable
data class M3U8Key(
    @SerialName("method")
    val method: String = "",
    @SerialName("uri")
    val uri: String? = null,
    @SerialName("iv")
    val iv: String? = null,
    @SerialName("keyformat")
    val keyFormat: String? = null,
    @SerialName("keyformatversions")
    val keyFormatVersions: String? = null,
)

@Serializable
data class M3U8Start(
    @SerialName("time_offset")
    val timeOffset: Double = 0.0,
    @SerialName("precise")
    val precise: Boolean? = null,
    @SerialName("other_attributes")
    val otherAttrs: Map<String, String>? = null,
)

// EXT-X-MEDIA tags
@Serializable
data class M3U8Media(
    @SerialName("media_type")
    val mediaType: String = "",
    @SerialName("uri")
    val uri: String? = null,
    @SerialName("group_id")
    val groupId: String = "",
    @SerialName("language")
    val language: String? = null,
    @SerialName("assoc_language")
    val assocLanguage: String? = null,
    @SerialName("name")
    val name: String = "",
    @SerialName("default")
    val isDefault: Boolean = false,
    @SerialName("autoselect")
    val isAutoSelect: Boolean = false,
    @SerialName("forced")
    val isForced: Boolean = false,
    @SerialName("instream_id")
    val instreamId: String? = null,
    @SerialName("characteristics")
    val characteristics: String? = null,
    @SerialName("channels")
    val channels: String? = null,
    @SerialName("other_attributes")
    val otherAttrs: Map<String, String>? = null,
)

@Serializable
data class M3U8ExtTag(
    @SerialName("tag")
    val tag: String = "",
    @SerialName("rest")
    val rest: String? = null,
)

@Serializable
data class M3U8MediaSegment(
    @SerialName("uri")
    val uri: String = "",
    @SerialName("duration")
    val duration: Double = 0.0,
    @SerialName("title")
    val title: String? = null,
    @SerialName("byte_range")
    val byteRange: M3U8ByteRange? = null,
    @SerialName("discontinuity")
    val isDiscontinuity: Boolean = false,
    @SerialName("key")
    val key: M3U8Key? = null,
    @SerialName("map")
    val map: M3U8Map? = null,
    @SerialName("program_date_time")
    val programDateTime: Long? = null,
    @SerialName("daterange")
    val dateRange: M3U8DateRange? = null,
    @SerialName("unknown_tags")
    val unknownTags: List<M3U8ExtTag> = emptyList(),
)

@Serializable
data class M3U8ByteRange(
    @SerialName("length")
    val length: Long = 0,
    @SerialName("offset")
    val offset: Long? = null,
)

@Serializable
data class M3U8Map(
    @SerialName("uri")
    val uri: String = "",
    @SerialName("byte_range")
    val byteRange: M3U8ByteRange? = null,
    @SerialName("other_attributes")
    val otherAttrs: Map<String, String>? = null,
)

@Serializable
data class M3U8DateRange(
    @SerialName("id")
    val id: String = "",
    @SerialName("class")
    val clazz: String? = null,
    @SerialName("start_date")
    val startDate: Long = 0,
    @SerialName("end_date")
    val endDate: Long? = null,
    @SerialName("duration")
    val duration: Double? = null,
    @SerialName("planned_duration")
    val plannedDuration: Double? = null,
    @SerialName("x_prefixed")
    val xPrefixed: Map<String, String>? = null,
    @SerialName("end_on_next")
    val isEndOnNext: Boolean = false,
    @SerialName("other_attributes")
    val otherAttrs: Map<String, String>? = null,
)

@Serializable
data class M3U8Resolution(
    val width: Int = 0,
    val height: Int = 0,
)

package wmt.downloader.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asExecutor

@Database(
    entities = [
        DownloadTaskEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
internal abstract class DownloadDatabase : RoomDatabase() {
    abstract fun downloadTaskDao(): DownloadTaskDao

    companion object {
        fun newDatabase(context: Context): DownloadDatabase {
            return Room.databaseBuilder<DownloadDatabase>(
                context = context.applicationContext,
                name = "wmt_media_downloader.db",
            ).setQueryCoroutineContext(SupervisorJob() + Dispatchers.IO)
                .build()
        }
    }
}

package wmt.downloader

import android.content.Context
import androidx.collection.MutableScatterMap
import androidx.media3.downloader.internal.DispatchQueueThread
import androidx.media3.downloader.util.Log
import androidx.media3.downloader.util.UrlUtil
import io.ktor.client.request.get
import io.ktor.client.statement.request
import io.ktor.http.isSuccess
import io.ktor.http.userAgent
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import wmt.downloader.database.DownloadDatabase
import wmt.downloader.database.DownloadTaskEntity
import wmt.downloader.define.DownloadTaskState
import wmt.downloader.define.VideoType
import wmt.downloader.http.newHttpClient
import wmt.downloader.task.DownloadTask
import wmt.downloader.task.DownloadTaskInfo
import wmt.downloader.task.DownloadTaskQueue
import wmt.downloader.task.executable
import wmt.downloader.task.m3u8.M3U8DownloadTask
import wmt.downloader.task.normal.NormalDownloadTask
import java.io.File
import kotlin.coroutines.CoroutineContext

/**
 * 视频下载器
 */
object MediaDownloader : CoroutineScope {
    internal const val TAG = "MediaDownloader"

    internal val cacheDir: File get() = config.cacheDir ?: applicationContext.cacheDir.resolve("wmt")

    // 单线程 HandlerThread
    override val coroutineContext: CoroutineContext by lazy {
        val dispatcher = DispatchQueueThread("MediaDownloader").dispatcher
        val exceptionHandler = CoroutineExceptionHandler { _, e -> Log.e(tag = TAG, e = e) }
        SupervisorJob() + dispatcher + exceptionHandler
    }

    private lateinit var applicationContext: Context
    private lateinit var config: MediaDownloadConfig

    private val database by lazy {
        DownloadDatabase.newDatabase(applicationContext).downloadTaskDao()
    }

    private val taskQueue = DownloadTaskQueue()
    // key: url
    private val runningTasks = MutableScatterMap<String, DownloadTask>()
    private var downloadJob: Job? = null

    init {
//        try {
//            System.loadLibrary("downloader")
//        } catch (e: Exception) {
//            Log.e(e = e)
//        }
    }

    /** 初始化 */
    fun init(context: Context, config: MediaDownloadConfig = MediaDownloadConfig()) {
        this.applicationContext = context.applicationContext
        this.config = config
        Log.enable = config.enableLog
//        CApi.a1(Log.enable, "${Log.TAG}/Native")
    }

    fun updateConfig(config: MediaDownloadConfig) {
        this.config = config
        taskQueue.notifyUpdate()
    }

    /** 获取下载任务列表 */
    suspend fun getDownloadTasks(): List<DownloadTaskInfo> = withContext(coroutineContext) {
        database.getDownloadTasks().map {
            taskQueue.findOrAdd(it.url) {
                DownloadTaskInfo(
                    id = it.id,
                    url = it.url,
                    originUrl = it.origin_url,
                    resolution = it.resolution,
                    filename = it.filename,
                    title = it.title,
                    coverUrl = it.cover_url,
                    createTime = it.create_time,
                    videoType = it.video_type,
                    mimeType = it.mime_type,
                    coverLocalPath = it.cover_local_path,
                    state = if (it.state == DownloadTaskState.Downloading) DownloadTaskState.Paused else it.state,
                    progress = it.progress,
                    totalBytes = it.total_bytes,
                    receivedBytes = it.received_bytes,
                )
            }
        }
    }

    /**
     * 启动下载任务队列
     * - 如果队列中已存在可执行任务, 将立即按排队顺序启动
     * - 如果队列中不存在可执行任务, 将一直等待, 直到 [DownloadTaskQueue.notifyUpdate] 被调用
     *
     * 任务是否可执行由 [executable] 决定,
     * 同时执行的任务数受 [MediaDownloadConfig.parallelism] 控制
     */
    fun launchDownloadTaskQueue() = launch {
        if (downloadJob?.isActive == true) return@launch
        downloadJob = taskQueue.observeUpdate(this) {
            select()
        }
    }

    /** 开始下载/恢复下载 */
    fun download(info: DownloadTaskInfo) {
        if (info.url.isEmpty()) return

        launchDownloadTaskQueue()
        pendingTask(info)
        prepareTask(info)
    }

    /** 暂停下载 */
    fun pause(info: DownloadTaskInfo) {
        val task = runningTasks.remove(info.url) ?: return
        task.stop()
        info.state = DownloadTaskState.Paused
    }

    /** 删除下载任务 */
    fun delete(info: DownloadTaskInfo, deleteFile: Boolean) {
        pause(info)
        deleteFromDatabase(info)
        if (deleteFile) {

            // TODO delete file
        }
    }

    // 加入队列
    private fun pendingTask(info: DownloadTaskInfo) = launch {
        if (info.state <= DownloadTaskState.NotSet) {
            info.state = DownloadTaskState.Pending
        }
        // 添加或更新数据库
        addOrUpdateToDatabase(info)
        // 加入任务队列
        taskQueue.add(info)
    }

    // 准备下载
    private fun prepareTask(info: DownloadTaskInfo) = launch {
        if (info.state != DownloadTaskState.Pending) return@launch

        // supervisorScope 挂起, 直到内部 launch 的所有子协程执行完成
        supervisorScope {
            val client = newHttpClient(
                cacheFile = applicationContext.cacheDir,
                enableLog = Log.enable,
                logTag = "${Log.TAG}/$TAG",
            )

            // 下载封面图片
            if (info.coverLocalPath.isNullOrEmpty() && !info.coverUrl.isNullOrEmpty()) {
                launch(Dispatchers.IO) {
                    // TODO
                }
            }

            // 获取 url 类型
            launch(Dispatchers.IO) {
                val response = client.get(info.url) {
                    userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36")
                }
                if (response.status.isSuccess()) {
                    val url = response.request.url
//                    if (info.url == url.toString()) {
//                        Log.i(msg = "[${response.duration}] prepare url=${url}")
//                    } else {
//                        Log.i(msg = "[${response.duration}] prepare url=${url}, origin=${info.url}")
//                    }

                    info.filename = UrlUtil.getFileName(url.toString(), true)
                    info.videoType = VideoType.from(UrlUtil.getFileExtension(url.toString()))
                } else {
//                    Log.i(msg = "[${response.duration}] prepare error=${response.status}, url=${info.url}")
                    info.state = DownloadTaskState.Error
                }
            }
        }

        if (info.state != DownloadTaskState.Error) {
            info.state = DownloadTaskState.Prepared
        }
    }

    // 消费队列按最大并行数执行任务
    private suspend fun select() {
        while (true) {
            var diff = runningTasks.size - config.parallelism
            Log.i(msg = "select $diff")
            when {
                // 正在下载的任务 < 最大任务数
                diff < 0 -> {
                    if (taskQueue.size <= runningTasks.size) break

                    for (i in taskQueue.indices) {
                        val info = taskQueue[i]
                        // 查找排队中待下载的任务
                        if (info.executable()) {
                            if (info.state == DownloadTaskState.Pending) {
                                // 挂起直到 Prepared
                                info.stateFlow.waitUntil(DownloadTaskState.Prepared)
                            }

                            // 构造 task
                            val task = when (info.videoType) {
                                VideoType.M3U8 -> M3U8DownloadTask(info)
                                else -> NormalDownloadTask(info)
                            }

                            // 开始执行
                            info.state = DownloadTaskState.Downloading
                            task.start()

                            if (info.state == DownloadTaskState.Downloading) {
                                runningTasks[info.url] = task
                            }

                            diff += 1
                            if (diff == 0) break
                        }
                    }
                }
                // 配置的最大任务数变小, 需要减少下载任务
                diff > 0 -> {
                    val list = ArrayList<DownloadTask>(runningTasks.size)
                    runningTasks.forEach { _, value ->
                        list += value
                    }
                    // 后创建的排前面
                    list.sortByDescending { it.info.createTime }

                    for (i in 0 until diff) {
                        val task = list[i]
                        if (task.info.state == DownloadTaskState.Downloading) {
                            task.info.state = DownloadTaskState.Prepared
                        }
                        runningTasks.remove(task.info.url)

                        task.stop()
                    }
                }
                else -> break
            }

            delay(1000)
        }
    }

    private fun addOrUpdateToDatabase(info: DownloadTaskInfo) = launch {
        if (info.id == 0L) {
            info.id = database.addDownloadTask(DownloadTaskEntity(
                url = info.url,
                origin_url = info.originUrl,
                resolution = info.resolution,
                filename = info.filename,
                title = info.title,
                video_type = info.videoType,
                mime_type = info.mimeType,
                create_time = info.createTime,
                cover_url = info.coverUrl,
                cover_local_path = info.coverLocalPath,
                state = info.state,
                progress = info.progress,
                total_bytes = info.totalBytes,
                received_bytes = info.receivedBytes,
            ))
        } else {
            database.updateDownloadTask(DownloadTaskEntity(
                id = info.id,
                url = info.url,
                origin_url = info.originUrl,
                resolution = info.resolution,
                filename = info.filename,
                title = info.title,
                video_type = info.videoType,
                mime_type = info.mimeType,
                create_time = info.createTime,
                cover_url = info.coverUrl,
                cover_local_path = info.coverLocalPath,
                state = info.state,
                progress = info.progress,
                total_bytes = info.totalBytes,
                received_bytes = info.receivedBytes,
            ))
        }
    }

    private fun deleteFromDatabase(info: DownloadTaskInfo) = launch {
        if (info.id == 0L) return@launch
        database.deleteDownloadTask(info.id)
    }

    private suspend fun Flow<DownloadTaskState>.waitUntil(state: DownloadTaskState) {
        coroutineScope {
            onEach {
                if (it == state) currentCoroutineContext().cancel()
            }.launchIn(this)
        }
    }

}

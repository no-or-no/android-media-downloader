package wmt.downloader.define

@JvmInline
value class VideoType private constructor(val value: String) {
    companion object {
        val Unknown = VideoType("unknown")
        val AVI = VideoType("avi")
        val FLV = VideoType("flv")
        val M3U8 = VideoType("m3u8")
        val M4V = VideoType("m4v")
        val MKV = VideoType("mkv")
        val MOV = VideoType("mov")
        val MP4 = VideoType("mp4")
        val MPG = VideoType("mpg")
        val WEBM = VideoType("webm")
        val WMV = VideoType("wmv")

        fun from(ext: String) = when(val o = VideoType(ext)) {
            AVI, FLV, M3U8, M4V, MKV, MOV, MP4, MPG, WEBM, WMV -> o
            else -> Unknown
        }
    }

    val mimeType: String get() = when (this) {
        AVI -> "video/x-msvideo"
        FLV -> "video/x-flv"
        M4V -> "video/x-m4v"
        MKV -> "video/x-matroska"
        MOV -> "video/quicktime"
        MP4 -> "video/mp4"
        MPG -> "video/mpeg"
        WEBM -> "video/webm"
        WMV -> "video/x-ms-wmv"
        else -> ""
    }
}
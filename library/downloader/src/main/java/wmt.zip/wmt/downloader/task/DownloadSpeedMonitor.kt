package wmt.downloader.task

import androidx.media3.downloader.internal.DispatchQueueThread
import androidx.media3.downloader.util.formatedBytes
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import wmt.downloader.MediaDownloader

internal fun DownloadTaskInfo.speedMonitor(): Job {
    val thread = DispatchQueueThread("download-timer-$id")
    return MediaDownloader.launch(thread.dispatcher) {
        var lastBytes = monitorBytes.value
        while (isActive) {
            delay(1000)
            val newBytes = monitorBytes.value
            val diff = newBytes - lastBytes
            lastBytes = newBytes
            monitorBytesPerSecond.value = diff.formatedBytes().let {
                if (it.isNotEmpty()) "$it/s" else ""
            }
        }
    }.apply {
        invokeOnCompletion {
            monitorBytesPerSecond.value = ""
            thread.recycle()
        }
    }
}
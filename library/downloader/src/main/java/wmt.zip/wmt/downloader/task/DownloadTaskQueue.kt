@file:Suppress("NOTHING_TO_INLINE")
package wmt.downloader.task

import android.service.notification.Condition
import androidx.collection.MutableScatterMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import wmt.downloader.MediaDownloader

/**
 * 下载任务队列
 */
internal class DownloadTaskQueue {

    private val deque = ArrayDeque<DownloadTaskInfo>()
    private val map = MutableScatterMap<String, DownloadTaskInfo>()
    private val signal = MutableStateFlow(0)

    val size: Int get() = deque.size
    val indices: IntRange get() = deque.indices

    inline fun isEmpty(): Boolean = size == 0

    fun add(info: DownloadTaskInfo, sort: Boolean = true) {
        if (map[info.url] != null) return
        map[info.url] = info
        deque.addLast(info)
        if (sort) {
            deque.sortBy { it.createTime }
        }
        notifyUpdate()
    }

    operator fun get(index: Int): DownloadTaskInfo = deque[index]

    fun findOrAdd(url: String, create: () -> DownloadTaskInfo): DownloadTaskInfo {
        return map[url] ?: create().also { add(it, false) }
    }

    fun remove(info: DownloadTaskInfo) {
        map.remove(info.url)
        deque.removeIf { it.url == info.url }
        notifyUpdate()
    }

    fun notifyUpdate() {
        signal.update { it + 1 }
    }

    fun observeUpdate(scope: CoroutineScope, action: suspend () -> Unit): Job {
        return signal.onEach { action() }.launchIn(scope)
    }

}
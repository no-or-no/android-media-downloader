@file:Suppress("PropertyName")
package wmt.downloader.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import wmt.downloader.define.DownloadTaskState
import wmt.downloader.define.VideoType

internal const val DownloadTask_Table = "download_task"

@Entity(DownloadTask_Table)
internal data class DownloadTaskEntity(
    @PrimaryKey(true)
    val id: Long = 0,
    val url: String,
    val origin_url: String,
    val resolution: String?,
    val filename: String?,
    val title: String,
    val video_type: VideoType,
    val mime_type: String,
    val create_time: Long,
    val cover_url: String?,
    val cover_local_path: String?,
    val state: DownloadTaskState,
    val progress: Float,
    val total_bytes: Long,
    val received_bytes: Long,
)
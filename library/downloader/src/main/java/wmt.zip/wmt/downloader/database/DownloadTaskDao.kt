package wmt.downloader.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
internal interface DownloadTaskDao {

    @Query("SELECT * FROM `$DownloadTask_Table` ORDER BY `create_time` ASC")
    suspend fun getDownloadTasks(): List<DownloadTaskEntity>

    @Insert
    suspend fun addDownloadTask(o: DownloadTaskEntity): Long

    @Update
    suspend fun updateDownloadTask(o: DownloadTaskEntity)

    @Query("DELETE FROM `$DownloadTask_Table` WHERE `id` = :id")
    suspend fun deleteDownloadTask(id: Long)

}